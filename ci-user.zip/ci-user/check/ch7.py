import base

if __name__ == "__main__":
    base.test([], [])